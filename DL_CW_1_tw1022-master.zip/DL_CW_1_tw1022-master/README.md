# Deep Learning Coursework 1

All questions are contained within dl_cw_1.ipynb. The "tests" folder is only required for students wishing to run the automated public tests within google colab.

